﻿using System;

namespace CyberChatbot
{
    public class Chatbot
    {
        public void DisplayLogo()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
   ______      __               ____        __ 
  / ____/_  __/ /_  ___  _____ / __ )____  / /_
 / /   / / / / __ \/ _ \/ ___// __  / __ \/ __/
/ /___/ /_/ / /_/ /  __/ /   / /_/ / /_/ / /_  
\____/\__, /_.___/\___/_/   /_____/\____/\__/  
     /____/                                    ");
            Console.WriteLine("--- Cybersecurity Awareness Assistant v1.0 ---");
            Console.ResetColor();
        }

        public void Dictionary(string input, string userName)
        {
            // STEP 4: Handle Empty/Null Input (Input Validation)
            if (string.IsNullOrWhiteSpace(input))
            {
                Console.WriteLine("Bot: Systems are idle. Please enter a query to proceed.");
                return;
            }

            string cleanInput = input.ToLower().Trim();

            // STEP 5: Main Logic using Switch and If-Else
            switch (cleanInput)
            {
                case "how are you":
                case "how are you?":
                    Console.WriteLine($"Bot: My encryption modules are stable, {userName}. I am ready to assist!");
                    break;

                case "purpose":
                case "what is your purpose?":
                    Console.WriteLine("Bot: I am designed to educate users on digital safety and South African cyber-risks.");
                    break;

                case "help":
                    Console.WriteLine("Bot: You can ask me about: 'Phishing', 'Firewalls', or 'Malware Types'.");
                    break;

                default:
                    // Expanded Knowledge Logic
                    if (cleanInput.Contains("phishing"))
                    {
                        Console.WriteLine("\nBot: [PHISHING ANALYSIS]");
                        Console.WriteLine("- Definition: Deceptive emails or sites used to steal banking credentials.");
                        Console.WriteLine("- Risk: Very high in SA. Always check for suspicious URLs.");
                    }
                    else if (cleanInput.Contains("firewall"))
                    {
                        Console.WriteLine("\nBot: [NETWORK SECURITY]");
                        Console.WriteLine("- Definition: A barrier that filters incoming and outgoing network traffic.");
                        Console.WriteLine("- Tip: Firewalls prevent hackers from finding open ports on your PC.");
                    }
                    else if (cleanInput.Contains("malware"))
                    {
                        Console.WriteLine("\nBot: [MALICIOUS SOFTWARE]");
                        Console.WriteLine("- Ransomware: Locks your files and demands payment.");
                        Console.WriteLine("- Spyware: Secretly records your keystrokes and passwords.");
                        Console.WriteLine("- Tip: Keep your antivirus updated to stop these threats.");
                    }
                    else
                    {
                        // Handle Unknown Input
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"Bot: Error: '{input}' not found in security database. Try asking for 'help'.");
                        Console.ResetColor();
                    }
                    break;
            }
        }
    }
}