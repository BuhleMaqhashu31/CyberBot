﻿using System;

namespace CyberChatbot
{
    class Program
    {
        static void Main(string[] args)
        {
            Chatbot bot = new Chatbot();
            AudioPlayer audio = new AudioPlayer();

            Console.Title = "Cyber Awareness Assistant";
            bot.DisplayLogo();

            // Step 1: Voice Greeting
            audio.PlayGreeting("Buhle.wav");

            // STEP 3: User Authentication & Personalization
            Console.Write("\nSYSTEM: Please enter your name to initialize: ");
            string nameInput = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(nameInput)) nameInput = "Guest_User";

            User currentUser = new User(nameInput);

            // --- UPDATED LINE BELOW ---
            Console.WriteLine($"\n[ACCESS GRANTED] Welcome, {currentUser.Name}.");
            Console.WriteLine("Bot: I am online and secure. Please ask me a question about Phishing, Firewalls, or Malware to begin.\n");

            bool running = true;
            while (running)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write($"{currentUser.Name} > ");
                Console.ResetColor();

                string input = Console.ReadLine();

                // Exit condition
                if (input?.ToLower() == "exit" || input?.ToLower() == "quit")
                {
                    running = false;
                    Console.WriteLine("Bot: Systems shutting down. Stay safe online!");
                    System.Threading.Thread.Sleep(1500);
                }
                else
                {
                    bot.Respond(input, currentUser.Name);
                }
            }
        }
    }
}