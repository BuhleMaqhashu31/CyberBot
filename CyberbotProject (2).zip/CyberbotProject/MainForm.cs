﻿using CyberChatbot;
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CyberChatbot
{
    public partial class MainForm : Form
    {
        // Interface UI Components
        private RichTextBox rtbChatHistory;
        private TextBox txtUserInput;
        private Button btnSend;
        private Panel headerPanel;
        private Label lblTitle;

        // Core logic and engine components
        private Chatbot botEngine;
        private AudioPlayer audioPlayer;
        private string userName = "User";

        public MainForm()
        {
            InitializeComponentLayout();

            botEngine = new Chatbot();
            audioPlayer = new AudioPlayer();
        }

        // This code draws the workspace window frame dynamically
        private void InitializeComponentLayout()
        {
            this.Size = new Size(500, 600);
            this.Text = "Cyber Security Awareness Assistant v2.0";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            // 1. Header Design Panel
            headerPanel = new Panel { Size = new Size(500, 60), Dock = DockStyle.Top, BackColor = Color.DarkCyan };
            lblTitle = new Label { Text = "🛡️ CYBER BOT AWARENESS ASSISTANT", ForeColor = Color.White, Font = new Font("Arial", 12, FontStyle.Bold), Location = new Point(15, 20), AutoSize = true };
            headerPanel.Controls.Add(lblTitle);

            // 2. Chat Log window history
            rtbChatHistory = new RichTextBox { Location = new Point(20, 80), Size = new Size(445, 400), ReadOnly = true, BackColor = Color.WhiteSmoke, Font = new Font("Arial", 10) };

            // 3. Text User input channel
            txtUserInput = new TextBox { Location = new Point(20, 500), Size = new Size(320, 30), Font = new Font("Arial", 11) };

            // 4. Send operational hook button
            btnSend = new Button { Location = new Point(355, 498), Size = new Size(110, 32), Text = "Send Inquiry", BackColor = Color.LightGray, Font = new Font("Arial", 9, FontStyle.Bold) };
            btnSend.Click += new System.EventHandler(this.btnSend_Click);

            // Add elements to the display frame
            this.Controls.Add(headerPanel);
            this.Controls.Add(rtbChatHistory);
            this.Controls.Add(txtUserInput);
            this.Controls.Add(btnSend);

            this.Load += new System.EventHandler(this.MainForm_Load);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            AppendChatText("SYSTEM INITIALIZATION...\n", Color.DarkBlue, true);
            AppendChatText("Bot: Welcome! Please enter your name in the chat to begin personalization.\n\n", Color.Blue, false);

            try
            {
                // Fires the multimedia audio voice greeting setup
                audioPlayer.PlayGreeting("Buhle.wav");
            }
            catch (Exception ex)
            {
                AppendChatText($"[AUDIO NOTICE] Could not play greeting: {ex.Message}\n\n", Color.Red, false);
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string rawInput = txtUserInput.Text;
            if (string.IsNullOrWhiteSpace(rawInput)) return;

            AppendChatText($"{userName}: ", Color.Green, true);
            AppendChatText($"{rawInput}\n", Color.Black, false);

            // Step 3 Alignment: Handle initial personalization and link to User class logic indirectly
            if (userName == "User")
            {
                userName = rawInput.Trim();
                AppendChatText($"[ACCESS GRANTED] Welcome, {userName}.\n", Color.DarkGoldenrod, true);
                AppendChatText("Bot: I am online and secure. Please ask me a question about Phishing, Firewalls, or Malware to begin.\n\n", Color.Blue, false);
                txtUserInput.Clear();
                return;
            }

            // CAPTURE CONSOLE OUTPUT: Catch whatever botEngine.Respond prints via Console.WriteLine
            using (StringWriter writer = new StringWriter())
            {
                TextWriter oldOut = Console.Out;
                Console.SetOut(writer);

                // Run your core background response logic
                botEngine.Dictionary(rawInput, userName);

                Console.SetOut(oldOut);
                string botReply = writer.ToString().Trim();

                // Append the captured output cleanly to your graphic history window
                if (!string.IsNullOrEmpty(botReply))
                {
                    AppendChatText($"{botReply}\n\n", Color.Blue, false);
                }
            }

            txtUserInput.Clear();
            rtbChatHistory.ScrollToCaret();
        }

        private void AppendChatText(string text, Color color, bool isBold)
        {
            rtbChatHistory.SelectionStart = rtbChatHistory.TextLength;
            rtbChatHistory.SelectionLength = 0;
            rtbChatHistory.SelectionColor = color;

            if (isBold)
                rtbChatHistory.SelectionFont = new Font(rtbChatHistory.Font, FontStyle.Bold);
            else
                rtbChatHistory.SelectionFont = new Font(rtbChatHistory.Font, FontStyle.Regular);

            rtbChatHistory.AppendText(text);
            rtbChatHistory.SelectionLength = 0;
        }
    }
}
