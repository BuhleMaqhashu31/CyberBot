﻿using System;
using System.IO;
using System.Media;

namespace CyberChatbot
{
    public class AudioPlayer
    {
        public void PlayGreeting(string fileName)
        {
            string runningFolder = AppDomain.CurrentDomain.BaseDirectory;
            string fullPath = Path.Combine(runningFolder, fileName);

            // This prints a message back to the Console stream (which your MainForm intercepts)
            Console.WriteLine($"[DEBUG] Audio engine looking here:\n{fullPath}\n");

            if (!File.Exists(fullPath))
            {
                Console.WriteLine("[DEBUG] RESULT: File does NOT exist in that folder!\n");
                return;
            }

            try
            {
                using (SoundPlayer player = new SoundPlayer(fullPath))
                {
                    player.Load(); // Force the system to load it into memory first
                    player.Play();
                    Console.WriteLine("[DEBUG] RESULT: Play command sent successfully!\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DEBUG] RESULT: File found, but Windows failed to play it.\nError: {ex.Message}\n");
            }
        }
    }
}